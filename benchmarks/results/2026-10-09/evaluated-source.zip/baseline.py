"""Versioned snapshots for incremental adoption of deterministic rules."""

import json
from collections import Counter
from pathlib import Path


def finding_key(finding: dict) -> tuple[str, str, int]:
    return finding["rule_id"], finding["file"], finding["line"]


def write_baseline(path: Path, findings: list[dict]) -> None:
    entries = [
        {"rule_id": rule_id, "file": file, "line": line}
        for rule_id, file, line in sorted(finding_key(item) for item in findings)
    ]
    path.write_text(json.dumps({"version": 1, "findings": entries}, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")


def load_baseline(path: Path) -> Counter:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"baseline 无法读取：{exc}") from exc
    if not isinstance(data, dict) or data.get("version") != 1 or not isinstance(data.get("findings"), list):
        raise ValueError("baseline 格式无效：需要 version=1 和 findings 数组")
    keys = Counter()
    for item in data["findings"]:
        if (not isinstance(item, dict) or not isinstance(item.get("rule_id"), str)
                or not isinstance(item.get("file"), str) or type(item.get("line")) is not int
                or item["line"] < 0):
            raise ValueError("baseline 包含无效发现项")
        keys[finding_key(item)] += 1
    return keys


def filter_baseline(findings: list[dict], known: Counter) -> tuple[list[dict], int]:
    remaining = known.copy()
    new = []
    suppressed = 0
    for finding in findings:
        key = finding_key(finding)
        if remaining[key] > 0:
            remaining[key] -= 1
            suppressed += 1
        else:
            new.append(finding)
    return new, suppressed
